function sentemail(event) {
   
    var nombre = $('#nombre').val();
    var correo = $('#correo').val();
    var telefono = $('#telefono').val();
    var personas = $('#personas').val();
    
    window.open(`mailto:pub@quechimba.vip?subject=Envio de Reserva&body=Nombre%3A%20%20${nombre}%0ACorreo%3A%20${correo}%0ATelefono%3A%20%20${telefono}%0ANumero%20de%20Personas%3A%20${personas}`,"_self")
}